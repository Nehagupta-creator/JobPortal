/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author ABC
 */
public class SendingMail {
    
   static  String from_mail="gupta11288@gmail.com";
     static String mail_password="96105830neha";
    public static  void sendMail(String email1, String subject1, String message){
        
       // 1. create a instance of property class
        Properties props= new Properties();
        props.put("mail.smtp.host","smtp.gmail.com");
        props.put("mail.smtp.port","587"); 
        props.put("mail.smtp.auth", "true");
        props.put("mails.smtp.starttls.enable","true");
        
        //2 create session object
        
        Session session= Session.getInstance(props, new Authenticator() {
            
          @Override
          protected PasswordAuthentication getPasswordAuthentication(){
              
              return new PasswordAuthentication(from_mail, mail_password);
              
              
              
               
           }
            
            
            
});
       try{
       
           MimeMessage mess=new MimeMessage(session);
           mess.setFrom(new InternetAddress(from_mail));
           mess.addRecipient(Message.RecipientType.TO, new InternetAddress(email1));
           mess.setSubject(subject1);
           mess.setText(message);
           Transport.send(mess);
      
       }
       catch(Exception e)
       {
         e.printStackTrace();
       
       }

}
    
}
