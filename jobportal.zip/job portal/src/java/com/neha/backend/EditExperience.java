/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class EditExperience extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     
        String id2=req.getParameter("id1");
       String company2=req.getParameter("company1");
       String location2=req.getParameter("location1");
       String year2=req.getParameter("year1");
       String job_title2=req.getParameter("job_title1");
       String projects2=req.getParameter("project1");
       
       
       Connection con=null;
       try{
        con=DbConnection.getConnection();
        con.setAutoCommit(false);
       PreparedStatement ps= con.prepareStatement("update experience set company=?,location=?,year=?,job_title=?,projects=? where id=?");
       ps.setString(1,company2);
       ps.setString(2,location2);
       ps.setString(3,year2);
       ps.setString(4,job_title2);
       ps.setString(5,projects2);
       ps.setString(6,id2);
       
       int i=ps.executeUpdate();
       if(i>0)
       {
           con.commit();
         resp.sendRedirect("profile.jsp");
       }
       else{
           con.rollback();
          resp.sendRedirect("edit_experience.jsp");
       }
       
       }
       
       
       catch(Exception e)
       {
           try{
            con.rollback();
           }
           catch(Exception ee)
           {
               ee.printStackTrace();
           
           }
           e.printStackTrace();
       
       }
        finally
      {
          try{
          con.close();
          }
          catch(Exception e)
          {
           e.printStackTrace();
          }
      }
        
        
    }
    
    
}
