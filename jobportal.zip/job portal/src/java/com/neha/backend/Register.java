/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class Register extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          doService(req, resp);
    }
    

    
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        String name2=req.getParameter("name1");
        String email2=req.getParameter("email1");
        String pass2=req.getParameter("pass1");
        String gender2=req.getParameter("gender1");
        String[] field2=req.getParameterValues("field1");
        
        String city2=req.getParameter("city1");
         String fields="";
       if(field2!=null)
       {
       for(String s:field2)
       {
           
        fields=(fields+ " ,"  +s);
        
       }
       }
       //out.println(fields);
        Connection con=null;
        try{
          
           con=DbConnection.getConnection();
          
           con.setAutoCommit(false);
            PreparedStatement ps=con.prepareStatement("insert into register(name,email,password,gender, field,city) values(?,?,?,?,?,?)");
            ps.setString(1,name2);
            ps.setString(2,email2);
            ps.setString(3,pass2);
            ps.setString(4,gender2);
            
            ps.setString(5, fields);
            ps.setString(6,city2);
            int i=ps.executeUpdate();
            
            PreparedStatement ps1= con.prepareStatement("insert into about_user(email,about,skills) values(?,?,?)");
            ps1.setString(1, email2);
            ps1.setString(2, "");
            ps1.setString(3, "");
           int i1= ps1.executeUpdate();
           
           
           
           PreparedStatement ps2= con.prepareStatement("insert into profile_pics(email,path) values(?,?)");
            ps2.setString(1, email2);
            ps2.setString(2, "profile.png");
            int i2=ps2.executeUpdate();
            
           
            
            if(i>0 && i1>0 && i2>0 )
            {
                con.commit();
                    HttpSession session=req.getSession();
                    session.setAttribute("session_name", name2);
                    session.setAttribute("session_email", email2);
                    session.setAttribute("session_city", city2);
                    session.setAttribute("session_gender", gender2);
                    session.setAttribute("session_field", fields);
                    session.setAttribute("session_about", "");
                    session.setAttribute("session_skills", "");
                    
                     session.setAttribute("session_profilepic", "profile.png");
                
                
              resp.sendRedirect("profile.jsp");
            }
            else
            {
                con.rollback();
             resp.sendRedirect("register.jsp");
            }
        }
        catch(Exception e)
        {
            try{
             con.rollback();
            }
            catch(Exception ee)
            {
            ee.printStackTrace();
            }
            e.printStackTrace();
        }
                finally
      {
          try{
          con.close();
          }
          catch(Exception e)
          {
           e.printStackTrace();
          }
      }

        
    }
    
    
}
