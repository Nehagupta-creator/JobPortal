/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter(); 
         HttpSession session=req.getSession();
        
        
        String email2=req.getParameter("email1");
        String pass2=req.getParameter("pass1");
        String remember2=req.getParameter("remember1");
           
            Connection con=null;
         try{
             con=DbConnection.getConnection();
            
           
            PreparedStatement ps=con.prepareStatement("select * from register where email=? and password=?");
            ps.setString(1,email2);
             ps.setString(2,pass2);
             ResultSet rs=ps.executeQuery();
             if(rs.next())
            {
                      if(remember2 == null || remember2.equals("null"))
                      {
                          remember2="";
                      }
                 
                  if( remember2.equals("rememberme"))
                  {
                   
                      Cookie ck=new Cookie("c_email", email2);
                      ck.setMaxAge(60*60*24*365);
                      resp.addCookie(ck);
                        
                      Cookie ck1=new Cookie("status", "true");
                      ck1.setMaxAge(60*60*24*365);
                      resp.addCookie(ck1);
                    
                   
                 }
            
                  
                  RequestDispatcher rd= req.getRequestDispatcher("GetUserData");
                  rd.include(req, resp);
                  
                  
                  resp.sendRedirect("profile.jsp");
                 
                    
              }  
            
              
             else
             {
                
             
//                 RequestDispatcher rd1=req.getRequestDispatcher("header.jsp");
//                 rd1.include(req, resp);
//                 RequestDispatcher rd2=req.getRequestDispatcher("menubar.jsp");
//                 rd2.include(req, resp);
                 req.setAttribute("message", "Email and Password didn't match!!!!");
                 RequestDispatcher rd3=req.getRequestDispatcher("loginerror.jsp");
                 rd3.include(req, resp);
                 RequestDispatcher rd4=req.getRequestDispatcher("login.jsp");
                 rd4.include(req, resp);
                 
             }
            
    
}
          catch(Exception e)
        {
        out.print(e);
        }
          finally
      {
          try{
          con.close();
          }
          catch(Exception e)
          {
           e.printStackTrace();
          }
      }
    }
}