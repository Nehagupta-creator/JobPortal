package com.neha.backend;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 *
 * @author ABC
 */
public class Validation {
  private Pattern name;
    private Pattern email;
      private Pattern pass;
  private Matcher match;
    
    private static final String name_pattern="^[a-zA-Z ]{3,20}$";
       private static final String email_pattern="^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,15}$";
          private static final String pass_pattern="^[a-zA-Z]+[!@#\\$%\\^& 0-9]{3,7}$";

public Validation()
{
name=Pattern.compile(name_pattern);
email=Pattern.compile(email_pattern);
pass=Pattern.compile(pass_pattern);

}
public boolean nameValidate( final String name1)
{
 match=name.matcher(name1);
         return match.matches();
}

         public boolean emailValidate( final String email1)
{
 match=email.matcher(email1);
         return match.matches();

}
         public boolean passValidate( final String pass1)
{
 match=pass.matcher(pass1);
         return match.matches();

}
}
