/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class GetUserData  extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    
    

    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
       
      resp.setContentType("text/html");
      PrintWriter out=resp.getWriter(); 
      HttpSession session=req.getSession();
       
       
        
       String  email2=req.getParameter("email1");
        if(email2== null || email2.equals("null"))
       {         
          email2=(String)req.getAttribute("email1");
       }
        
        
        
        
        
        
         System.out.println(" i am on get user data page" +email2);
       
            String name1="",gender1="",field1="",city1="";
            Connection con=null;
         try{
             con=DbConnection.getConnection();
            
           
            PreparedStatement ps=con.prepareStatement("select * from register where email=?");
            ps.setString(1,email2);
            
             ResultSet rs=ps.executeQuery();
             if(rs.next())
              {
                  
               name1=rs.getString("name");
              city1=rs.getString("city");
              gender1=rs.getString("gender");
              field1=rs.getString("field");
                    
                    
                   
                    session.setAttribute("session_name", name1);
                    session.setAttribute("session_email", email2);
                    session.setAttribute("session_city", city1);
                    session.setAttribute("session_gender", gender1);
                    session.setAttribute("session_field", field1);
                String about1="",skills1="";
             
             PreparedStatement ps1=con.prepareStatement("select * from about_user where email=?");
             ps1.setString(1,email2);
             
             ResultSet rs1=ps1.executeQuery();
              while(rs1.next())
             
             {
               about1=rs1.getString("about");
                skills1=rs1.getString("skills");
                    
                    
             }   
              session.setAttribute("session_about", about1);
              session.setAttribute("session_skills", skills1);
                
               resp.sendRedirect("profile.jsp");
             
             String path2="";
            
             PreparedStatement ps2= con.prepareStatement("select * from profile_pics where email=?");
             ps2.setString(1, email2);
             ResultSet rs2=ps2.executeQuery();
             while(rs2.next())
             {
                 
              path2=rs2.getString("path");
           }
          session.setAttribute("session_profilepic",path2);
             resp.sendRedirect("profile.jsp");
              }
             
    
}
          catch(Exception e)
        {
        e.printStackTrace();
        }
          finally
      {
          try{
          con.close();
          }
          catch(Exception e)
          {
           e.printStackTrace();
          }
      }
    }
    
    
    
}
