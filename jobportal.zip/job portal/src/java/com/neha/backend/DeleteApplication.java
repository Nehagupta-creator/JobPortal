/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class DeleteApplication   extends HttpServlet{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                      HttpSession session=req.getSession();
                      String email=(String)session.getAttribute("session_email");
                      String jobid=req.getParameter("id1");
                    Connection con=null;
                     
                        try
                        {
                         con=DbConnection.getConnection();
                         con.setAutoCommit(false);
                         PreparedStatement ps= con.prepareStatement("delete from applyjob where email=? and jid=?");
                         ps.setString(1,email);
                         ps.setString(2,jobid);
                         
                         int i=ps.executeUpdate();
                        if (i>0)
                           {
                               con.commit();
                               resp.sendRedirect("profile.jsp");
                           }
                        else
                        {
                         con.rollback();
                         resp.sendRedirect("myapplyedjobs.jsp");
                        
                        }
                        }
                        catch(Exception e)
                            
                        {
                            try{
                            con.rollback();
                            
                            }
                            catch(Exception ee)
                            {
                            
                            ee.printStackTrace();
                            }
                            e.printStackTrace();
                        
                        }
                        finally
                        {
                        
                        try{
                            con.close();
                            
                            }
                            catch(Exception ee)
                            {
                            
                            ee.printStackTrace();
                            }
                        }
        
        
        
    }
    
    
    
    
    
}
