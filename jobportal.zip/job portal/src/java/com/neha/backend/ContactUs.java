/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class ContactUs  extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    
  
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String name=req.getParameter("name1");
        String email=req.getParameter("email1");
        String subject=req.getParameter("subject1");
        String message=req.getParameter("message1");
        Date d= new Date();
        SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyy");
        
        String date2=sdf.format(d);
        
        SimpleDateFormat sdf1= new SimpleDateFormat("HH:mm:ss");
        
        String time2=sdf1.format(d);
        
         
         Connection con=null;
        
        try{
        
           con=DbConnection.getConnection();
           con.setAutoCommit(false);
           PreparedStatement ps= con.prepareStatement("insert into contact_us(name, email,subject,message,date1, time) values(?,?,?,?,?,?)");
           ps.setString(1,name);
           ps.setString(2,email);
           ps.setString(3,subject);
           ps.setString(4,message);
           ps.setString(5,date2);
           ps.setString(6,time2);
        
          int i=ps.executeUpdate();
          
          if(i>0)
          {
           con.commit();
            
          String subject1="Thankyou";
           String message_send= "Thanku for your Query Our Team will Contact you as soon As Possible!!!" ;
           SendingMail.sendMail( email,subject1, message_send);
           
           
           
              req.setAttribute("success_msg",  "Your Request has been submit  our team will contact you as soon as possible!!");
              RequestDispatcher rd= req.getRequestDispatcher("successmessage.jsp");
              rd.include(req, resp);
              RequestDispatcher rd1= req.getRequestDispatcher("contact.jsp");
              rd1.include(req, resp);
          
             
          }  
          else
          {
            con.rollback();
            
            req.setAttribute("message", "Your request has not been sent!!");
            RequestDispatcher rd= req.getRequestDispatcher("loginerror.jsp");
              rd.include(req, resp);
              RequestDispatcher rd1= req.getRequestDispatcher("contact.jsp");
              rd1.include(req, resp);
          
          }
        
        }
        catch(Exception e)
        {
            try{
               con.rollback();
               RequestDispatcher rd= req.getRequestDispatcher("loginerror.jsp");
              rd.include(req, resp);
              RequestDispatcher rd1= req.getRequestDispatcher("contact.jsp");
              rd1.include(req, resp);
          
            }
            catch(Exception ee)
            {
            
            ee.printStackTrace();
            }
          e.printStackTrace();
        }
        finally{
        try{
        
        
        con.close();
        
        }
        catch(Exception e)
        {
        
         e.printStackTrace();
        }
        
        }
        
        
        
    }
    
    
    
    
}
