/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class AddEducation extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    

   
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out= resp.getWriter();
        String school2=req.getParameter("school1");
        String dgree2=req.getParameter("degree1");
        String grade2=req.getParameter("grade1");
        String year2=req.getParameter("year1");
        String description2=req.getParameter("description1");
        HttpSession session=req.getSession();
        String email2= (String)session.getAttribute("session_email");
        Connection con=null;
         try{
         
           con=DbConnection.getConnection();
           con.setAutoCommit(false);
            PreparedStatement ps=con.prepareStatement("insert into education(email, school,dgree,grade,year,description) values(?,?,?,?,?,?)");
            ps.setString(1,email2);
            ps.setString(2,school2);
            ps.setString(3,dgree2);
            ps.setString(4,grade2);
            ps.setString(5, year2);
            ps.setString(6,description2);
            int i=ps.executeUpdate();
            if(i>0)
            {
                con.commit();
              resp.sendRedirect("profile.jsp");
            
            }
            else
            {
                con.rollback();
            resp.sendRedirect("add_education.jsp");
            }
            
        
        
        
    }
    
    catch(Exception e)
    {
        try{
        con.rollback();
        }
        catch(Exception ee)
        {
         ee.printStackTrace();
        }
      out.println(e);
    }
    
    finally
    {
        try{
         con.close();
        }
        catch(Exception e)
        {
         e.printStackTrace();
        }

}
    
    } 
    
}
