/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.neha.connection.DbConnection;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class BuildResume extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
   try{
        HttpSession session=req.getSession();
        String email2=(String)session.getAttribute("session_email");
         String name2=(String)session.getAttribute("session_name");
         String profilepic2=(String)session.getAttribute("session_profilepic");
         String address2=req.getParameter("address1");
         String hobbies2=req.getParameter("hobbie1");
         String carrer2=req.getParameter("carrer1");
          String gender2=req.getParameter("gender1");
           String language2=req.getParameter("lang1");
           String dob2=req.getParameter("dob1"); 
           
           
           String resume_pdf_name=email2+".pdf";
           Document document=new Document();
           PdfWriter pdw=PdfWriter.getInstance(document, new FileOutputStream(PathDetails.RESUME_BUILDER+resume_pdf_name));
           document.open();
           String font_name="Arial";
            float font_size=18;
            int font_style=Font.BOLD;
           
           
           Paragraph p=new Paragraph("Resume" ,FontFactory.getFont(font_name, font_size, font_style, BaseColor.RED));
           document.add(p);
           
            
           Paragraph p1=new Paragraph(" ");
           document.add(p1);
           
           Image image1=Image.getInstance(PathDetails.PROFILE_PIC_PATH+profilepic2);
           image1.scaleAbsolute(100f, 100f);
           document.add(image1);
           
           
            
           Paragraph p3=new Paragraph(name2);
           document.add(p3);
            
           Paragraph p4=new Paragraph(email2);
           document.add(p4);
           Paragraph p6=new Paragraph(" ");
           document.add(p6);
           
           
           Paragraph p5=new Paragraph("Carrer Objective", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p5);
           
            
           
           Paragraph p7=new Paragraph(carrer2);
           document.add(p7);
           
           document.add(p6);
           Paragraph p8=new Paragraph("Educational Qualification", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p8);
           
           
           PdfPTable table=new PdfPTable(4);
           table.setSpacingBefore(20);
           PdfPCell c1=new PdfPCell(new Phrase("Year"));
           table.addCell(c1);
           PdfPCell c2=new PdfPCell(new Phrase("School/University"));
           table.addCell(c2);
           PdfPCell c3=new PdfPCell(new Phrase("Degree"));
           table.addCell(c3);
           PdfPCell c4=new PdfPCell(new Phrase("Grade"));
           table.addCell(c4);
            
           Connection con=null;
           String year="",school="", degree="",grade="";
           try{
               con=DbConnection.getConnection();
               PreparedStatement ps=con.prepareStatement("select * from education where email=?");
               ps.setString(1,email2);
               ResultSet rs= ps.executeQuery();
               while(rs.next())
               {
                   school=rs.getString("school");
                   degree=rs.getString("dgree");
                   grade=rs.getString("grade");
                   year=rs.getString("year");
                   table.addCell(year);
                   table.addCell(school);
                   table.addCell(degree);
                    table.addCell(grade);
               
               
               }    
           
           }
           catch(Exception e)
           {
               e.printStackTrace();
           
           } 
           finally{
           try{
           con.close();
           }
           catch(Exception ee)
           {
               ee.printStackTrace();
           
           }   
               
           }
           document.add(table);
           document.add(p1);
           Paragraph p9=new Paragraph("Experience", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p9);
           
           
           PdfPTable table1=new PdfPTable(4);
           table1.setSpacingBefore(20);
           PdfPCell c11=new PdfPCell(new Phrase("Company"));
           table.addCell(c11);
           PdfPCell c22=new PdfPCell(new Phrase("Location"));
           table.addCell(c22);
           PdfPCell c33=new PdfPCell(new Phrase("Year"));
           table.addCell(c33);
           PdfPCell c44=new PdfPCell(new Phrase("JobTitle"));
           table.addCell(c44);
            
           Connection con2=null;
           String company="",location="", year1="",jobtitle="";
           try{
               con2=DbConnection.getConnection();
               PreparedStatement ps1=con2.prepareStatement("select * from experience where email=?");
               ps1.setString(1,email2);
               ResultSet rs1= ps1.executeQuery();
               while(rs1.next())
               {
                   company=rs1.getString("company");
                   location=rs1.getString("location");
                   jobtitle=rs1.getString("job_title");
                   year1=rs1.getString("year");
                   table1.addCell(company);
                   table1.addCell(location);
                   table1.addCell(year1);
                    table1.addCell(jobtitle);
               
               
               }    
           
           }
           catch(Exception e)
           {
               e.printStackTrace();
           
           } 
           finally{
           try{
           con2.close();
           }
           catch(Exception ee)
           {
               ee.printStackTrace();
           
           }   
               
           }
           document.add(table1);
           document.add(p1);
           Paragraph p10=new Paragraph("Hobbies:", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p10);
           Paragraph p11=new Paragraph(hobbies2);
           document.add(p11);
           document.add(p1);
           Paragraph p12=new Paragraph("Personal Information:", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p12);
           Paragraph p13=new Paragraph("Name:"+name2);
           document.add(p13);
           Paragraph p14=new Paragraph("DOate of Birth:"   +dob2);
           document.add(p14);
           Paragraph p15=new Paragraph("Gender"+gender2);
           document.add(p15);
           Paragraph p16=new Paragraph("Language Profeciency  "   + language2);
           document.add(p16);
            document.add(p1);
           Paragraph p17=new Paragraph("Decleration:", FontFactory.getFont(font_name, font_size, BaseColor.RED));
           document.add(p17);
           Paragraph p18=new Paragraph("I do hereby declare all the above information. ");
           document.add(p18);
           document.add(p1);
           Date d=new Date();
           SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy");
           Paragraph p19=new Paragraph("Date:"   + sdf.format(d));
           document.add(p19);
          
           document.close();
           resp.sendRedirect("profile.jsp");
           
        }
        catch(Exception e)
        {
        
         e.printStackTrace();
        }    
         
    }
    
    
}
