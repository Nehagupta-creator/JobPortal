/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class searchlocation    extends HttpServlet{

    @Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
        
        
        String location1=req. getParameter("local");
        PrintWriter out=resp.getWriter();
        Connection con=null;
         String job_profile="", company="",location="",description="",id="",no_of_opennings="";
        try{
           con=DbConnection.getConnection();
           PreparedStatement ps= con.prepareStatement("select * from jobs where location LIKE '%"+location1+"%'");
           ResultSet rs= ps.executeQuery();
           
           while(rs.next())
           {
           id=rs.getString("id");
           job_profile=rs.getString("job_profile");
           company=rs.getString("company");
           location=rs.getString("location");
           description=rs.getString("description");    
           no_of_opennings=rs.getString("no_of_opening");
           
              out.print("<div style=\" border: 2px solid gray\">\n" +
"                        <span ><b>"+job_profile+"</b></span><br>\n" +
"                        <span>Company\n" +
"                            <i class=\"fa fa-home\"></i>\n" +
"                        "+company+"\n" +
"                         </span><br>\n" +
"                        \n" +
"                        <span>Location:\n" +
"                            <i class=\"fa fa-map-marker\" ></i>\n" +
"                        "+location+"\n" +
"                        </span><br>\n" +
"                                 <span>Description:\n" +
"                                     <i class=\"fa fa-edit\"></i>\n" +
"                                     \n" +
"                                     "+description+"\n" +
"                                 </span><br>\n" +
"                          <span>No.of.Openings\n" +
"                              <i class=\"fa fa-plus-square\"></i>\n" +
"                          "+no_of_opennings+"\n" +
"                             </span><br>\n" +
"\n" +
"                                       \n" +
"                             <a href=\"fullinfo.jsp?jid="+id+"\"> <input type=\"submit\" value=\"see more..\"/></a><br><br>\n" +
"                                   </div>");
                          
                            
           
           }   
         
        
        
        
         }
        catch(Exception e)
        {
            
            out.print(e);
            
        } 
        finally
        {
            try{
           con.close();
            }
            catch(Exception e)
            {
             e.printStackTrace();
            }
        }   
        
        
        
        
     
    }
    
    
    
}
