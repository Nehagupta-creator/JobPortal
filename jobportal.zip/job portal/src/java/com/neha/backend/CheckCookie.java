/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class CheckCookie  extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    
    
 
    
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
       
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
       
         String email="";
       
       Cookie[] ck1 = req.getCookies();

        if(ck1 != null)
        {  
           
        for (Cookie cookie : ck1)
      {
          if(cookie.getName() .equals("c_email"))
          {
                 email=cookie.getValue();
                 
                 req.setAttribute("email1", email);
                 RequestDispatcher rd=req.getRequestDispatcher("GetUserData");
                 rd.include(req, resp);
                
          }
              
          
         
         
    
           
        
      
       }
        }
         System.out.println("i am on check cookie page"  +email);
        
         
    
}
}
       
      
      
      
     
    
    
    
