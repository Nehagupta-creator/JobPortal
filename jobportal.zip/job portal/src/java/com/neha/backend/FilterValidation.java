/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class FilterValidation implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
      
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
     
     response.setContentType("text/html");
     PrintWriter out=response.getWriter();
     String name2=request.getParameter("name1");
        String email2=request.getParameter("email1");
        String pass2=request.getParameter("pass1");
        String gender2=request.getParameter("gender1");
        
       String city2=request.getParameter("city1");
       Validation  valid=new Validation();
       if(!valid.nameValidate(name2))
       {
           RequestDispatcher rd1=request.getRequestDispatcher("header.jsp");
           rd1.include(request, response);
            RequestDispatcher rd2=request.getRequestDispatcher("menubar.jsp");
           rd2.include(request, response);
            RequestDispatcher rd3=request.getRequestDispatcher("nameerror.jsp");
           rd3.include(request, response);
            RequestDispatcher rd4=request.getRequestDispatcher("registrationdiv.jsp");
           rd4.include(request, response);
            RequestDispatcher rd5=request.getRequestDispatcher("footer.jsp");
           rd5.include(request, response);
       }
      else if(!valid.emailValidate(email2))
       {
        RequestDispatcher rd1=request.getRequestDispatcher("header.jsp");
           rd1.include(request, response);
            RequestDispatcher rd2=request.getRequestDispatcher("menubar.jsp");
           rd2.include(request, response);
            RequestDispatcher rd3=request.getRequestDispatcher("emailerror.jsp");
           rd3.include(request, response);
            RequestDispatcher rd4=request.getRequestDispatcher("registrationdiv.jsp");
           rd4.include(request, response);
            RequestDispatcher rd5=request.getRequestDispatcher("footer.jsp");
           rd5.include(request, response); 
       }
      else if(!valid.passValidate(pass2))
       {
         RequestDispatcher rd1=request.getRequestDispatcher("header.jsp");
           rd1.include(request, response);
            RequestDispatcher rd2=request.getRequestDispatcher("menubar.jsp");
           rd2.include(request, response);
            RequestDispatcher rd3=request.getRequestDispatcher("passworderror.jsp");
           rd3.include(request, response);
            RequestDispatcher rd4=request.getRequestDispatcher("registrationdiv.jsp");
           rd4.include(request, response);
            RequestDispatcher rd5=request.getRequestDispatcher("footer.jsp");
           rd5.include(request, response);
       }
      else if(gender2==null || gender2.equals(""))
       {
         
       }
          else if(city2==null || city2.equals("Select city"))
       {
        
       }
          else
                  {
                  chain.doFilter(request, response);
                  }
        
       }

    @Override
    public void destroy() {
        
    }
    
}
