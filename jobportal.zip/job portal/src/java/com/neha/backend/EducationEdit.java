/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ABC
 */
public class EducationEdit extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    
   
   
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        PrintWriter out=resp.getWriter();
        
        String school2=req.getParameter("school1");
        String dgree2=req.getParameter("degree1");
        String grade2=req.getParameter("grade1");
        String year2=req.getParameter("year1");
        String description2=req.getParameter("description1");
        String id2=req.getParameter("id1");
        Connection con=null;
        try{
            con=DbConnection.getConnection();
            con.setAutoCommit(false);
            PreparedStatement ps=con.prepareStatement("update education set school=?,dgree=?,grade=?,year=?,description=? where id=?");
            ps.setString(1, school2);
            ps.setString(2, dgree2);
            ps.setString(3, grade2);
            ps.setString(4, year2);
            ps.setString(5, description2);
             ps.setString(6, id2);
             
            
            int i=ps.executeUpdate();
            if(i>0)
                
            {
                con.commit();
                resp.sendRedirect("profile.jsp");
            
            }
            else
            {
                con.rollback();
            resp.sendRedirect("education_edit.jsp");
            }
        
          }
        catch(Exception e)
        {
            try{
            con.rollback();
            }
            catch(Exception ee)
            {
                ee.printStackTrace();
            
            }
         out.println(e);
        }
         finally
      {
          try{
          con.close();
          }
          catch(Exception e)
          {
           e.printStackTrace();
          }
      }
        
    }
    
    
}
