/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ABC
 */
public class ApplyJobs extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doService(req, resp);
    }
    
    
    
    protected void doService(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         
        
        PrintWriter out=resp.getWriter();
       HttpSession session=req.getSession();
        String email2= (String)session.getAttribute("session_email");
       
        String jid=req.getParameter("id1");
        Date d=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyyy");
        String date1=sdf.format(d);
        SimpleDateFormat sdf1=new SimpleDateFormat("HH-mm-ssss");
        String time1=sdf1.format(d);
        Connection con=null;
        
        try
        {
          con=DbConnection.getConnection();
          con.setAutoCommit(false);
          PreparedStatement ps=con.prepareStatement("insert into applyjob(email,jid,date1,time1)values(?,?,?,?)");
          ps.setString(1,email2);
          ps.setString(2,jid);
          ps.setString(3,date1);
          ps.setString(4,time1);
         int i= ps.executeUpdate();
         if(i>0)
         {
           con.commit();
           req.setAttribute("success_msg", "You Have Successfully Applied to this Job!!");
            RequestDispatcher rd=req.getRequestDispatcher("successmessage.jsp");
            rd.include(req, resp);
              RequestDispatcher rd1=req.getRequestDispatcher("index.jsp");
             rd1.include(req, resp);
             
         
         } 
         else
         {
             con.rollback();
             resp.sendRedirect("fullinfo.jsp");
         
           }
        
        
         }
        catch(Exception e)
        {
            try{
            con.rollback();
            
             }
            catch(Exception ee)
            {
            ee.printStackTrace();
            }    
             out.print(e);
        
        } 
        finally{
        
        try{
            
            con.close();
        
        }
        catch(Exception e)
        {
            e.printStackTrace();
        
        
        }    
        
        
        }
        
    
    
    
    
}
}    
