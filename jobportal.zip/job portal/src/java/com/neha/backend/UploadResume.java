/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.backend;

import com.neha.connection.DbConnection;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author ABC
 */
public class UploadResume extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session=req.getSession();
        String email2=(String)session.getAttribute("session_email");
        String  file_name=null;
        try{
        DiskFileItemFactory factory=new DiskFileItemFactory();
        ServletFileUpload sfu=new  ServletFileUpload(factory);
        List<FileItem> items=sfu.parseRequest(req);
        FileItem item=items.get(1);
        String file_path=item.getName();
        File file= new File(file_path);
             file_name= file.getName();
             
             
             
             File f1=new File(PathDetails.RESUME_PATH+file_name);
             item.write(f1);
        }
        catch(Exception e)
        {
         e.printStackTrace();
        } 
        
        
        Connection con=null;
        try{
        
        con=DbConnection.getConnection();
        con.setAutoCommit(false);
        
        PreparedStatement ps= con.prepareStatement("select *  from resume where email=?");
        ps.setString(1, email2);
        ResultSet rs=ps.executeQuery();
        if(rs.next())
        {
        PreparedStatement ps1=con.prepareStatement("update resume set filename=? where email=?");
        ps1.setString(1,file_name);
        ps1.setString(2, email2);
        int i=ps1.executeUpdate();
        if(i>0)
        {
            con.commit();
            resp.sendRedirect("profile.jsp");
        
        }
        
//        session.setAttribute("session_resume", file_name);
        else
        {
           con.rollback();
           resp.sendRedirect("uploadresume.jsp");
        }
                
        
        
        }
        else
        {
        
         PreparedStatement ps2=con.prepareStatement("insert into resume(email,filename)values(?,?)");
         ps2.setString(1,email2);
         ps2.setString(2, file_name);
        int i1=ps2.executeUpdate();
        if(i1>0)
        {
          con.commit();
          resp.sendRedirect("profile.jsp");
        }
        
        else{
        con.rollback();
        resp.sendRedirect("uploadresume.jsp");
        
        
        }
        }
        
        
        }
        catch(Exception ee)
        {
            try{
             con.rollback();
            }
            catch(Exception e)
            {
            e.printStackTrace();
            
            }
          ee.printStackTrace();
        }
        finally
        {
        try{
         con.close();
        }
        catch(Exception e)
        {
         e.printStackTrace();
        }
        
        }
        
        
        
        
        
        
       
    }
    
    
}
