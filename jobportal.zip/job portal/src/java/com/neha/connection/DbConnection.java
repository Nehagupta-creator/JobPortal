/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neha.connection;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.mysql.jdbc.jdbc2.optional.MysqlXADataSource;
import java.sql.Connection;

/**
 *
 * @author ABC
 */
public class DbConnection {
    
    static Connection con;
    public static Connection getConnection(){
    try{
        MysqlDataSource db=new MysqlDataSource();
        db.setURL("jdbc:mysql://localhost:3306/jobportal");
        db.setUser("root");
        db.setPassword("root");
        con=db.getConnection();


      }
    
    catch(Exception e)
    {
     e.printStackTrace();
    }
    return con;  
}
   
}
